// محاسبه‌ی قیمت طلا و سکه‌ی ایران بر اساس قیمت اونس جهانی و نرخ دلار بازار (تومان)
//
// مبنای محاسبه:
//   ۱ اونس تروی = ۳۱.۱۰۳۴۷۶۸ گرم
//   قیمت هر گرم طلای خالص (۲۴ عیار) به تومان = (اونس دلار × دلار تومان) / 31.1034768
//   عیار ۱۸ = خلوص 750  ، عیار ۲۱ = 875 ، عیار ۲۲ = 916/22 ، عیار ۲۴ = 999
//
// قیمت ذاتی سکه = وزن طلای خالص سکه × قیمت هر گرم خالص.
// قیمت معاملاتی سکه معمولاً به‌خاطر «حباب» بالاتر است؛ ضریب حباب تقریبی لحاظ شده است.

const GRAMS_PER_OUNCE = 31.1034768;

export type GoldItem = {
  key: string;
  title: string;
  subtitle: string;
  tomanPerGram: number;
};

export type CoinItem = {
  key: string;
  title: string;
  subtitle: string;
  toman: number;
};

export function computeGoldPrices(ounceUsd: number, usdToman: number): GoldItem[] {
  const pure24PerGram = (ounceUsd * usdToman) / GRAMS_PER_OUNCE; // عیار ۹۹۹/۲۴
  const purity = {
    k24: 0.995,
    k22: 0.916,
    k21: 0.875,
    k18: 0.75,
    k14: 0.585,
  };
  const base = pure24PerGram; // هر گرم خالص

  return [
    {
      key: "ounce",
      title: "انس طلای جهانی",
      subtitle: "هر اونس (دلار)",
      tomanPerGram: ounceUsd, // نمایش دلاری جدا انجام می‌شود
    },
    {
      key: "g24",
      title: "طلای ۲۴ عیار",
      subtitle: "هر گرم (تومان)",
      tomanPerGram: base * purity.k24,
    },
    {
      key: "g22",
      title: "طلای ۲۲ عیار",
      subtitle: "هر گرم (تومان)",
      tomanPerGram: base * purity.k22,
    },
    {
      key: "g21",
      title: "طلای ۲۱ عیار",
      subtitle: "هر گرم (تومان)",
      tomanPerGram: base * purity.k21,
    },
    {
      key: "g18",
      title: "طلای ۱۸ عیار",
      subtitle: "هر گرم (تومان)",
      tomanPerGram: base * purity.k18,
    },
    {
      key: "g14",
      title: "طلای ۱۴ عیار",
      subtitle: "هر گرم (تومان)",
      tomanPerGram: base * purity.k14,
    },
    {
      key: "mesghal",
      title: "مثقال طلا",
      subtitle: "هر مثقال ۱۷ عیار (تومان)",
      tomanPerGram: base * 0.705 * 4.6083, // مثقال = ۴.۶۰۸۳ گرم، عیار آبشده ۷۰۵
    },
  ];
}

// وزن طلای خالص هر سکه (گرم) با عیار ۹۰۰
const COIN_PURE_GOLD = {
  emami: 7.3224, // سکه امامی / بهار آزادی جدید
  bahar: 7.3224, // بهار آزادی
  nim: 3.6612, // نیم سکه
  rob: 1.8306, // ربع سکه
  gerami: 0.9, // سکه گرمی ~ ۱ گرم
};

// ضریب حباب تقریبی بازار برای هر نوع سکه
const COIN_BUBBLE = {
  emami: 1.28,
  bahar: 1.24,
  nim: 1.45,
  rob: 1.75,
  gerami: 2.0,
};

export function computeCoinPrices(ounceUsd: number, usdToman: number): CoinItem[] {
  const pure24PerGram = (ounceUsd * usdToman) / GRAMS_PER_OUNCE;
  const intrinsic = (grams: number, purity = 0.9) => pure24PerGram * grams * (purity / 0.995);

  return [
    {
      key: "emami",
      title: "سکه امامی",
      subtitle: "طرح جدید (تومان)",
      toman: intrinsic(COIN_PURE_GOLD.emami) * COIN_BUBBLE.emami,
    },
    {
      key: "bahar",
      title: "سکه بهار آزادی",
      subtitle: "طرح قدیم (تومان)",
      toman: intrinsic(COIN_PURE_GOLD.bahar) * COIN_BUBBLE.bahar,
    },
    {
      key: "nim",
      title: "نیم سکه",
      subtitle: "بهار آزادی (تومان)",
      toman: intrinsic(COIN_PURE_GOLD.nim) * COIN_BUBBLE.nim,
    },
    {
      key: "rob",
      title: "ربع سکه",
      subtitle: "بهار آزادی (تومان)",
      toman: intrinsic(COIN_PURE_GOLD.rob) * COIN_BUBBLE.rob,
    },
    {
      key: "gerami",
      title: "سکه گرمی",
      subtitle: "یک گرمی (تومان)",
      toman: intrinsic(COIN_PURE_GOLD.gerami) * COIN_BUBBLE.gerami,
    },
  ];
}
