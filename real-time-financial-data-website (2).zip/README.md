# نرخ لحظه‌ای واقعی

سایت React/Vite با فونت وزیرمتن برای نمایش قیمت‌های واقعی و جاری ارز، افغانی، رمزارز، طلا و سکه. برنامه برای Railway آماده است و یک سرور Node داخلی دارد تا APIها از سمت سرور خوانده شوند، نه از مرورگر.

## منابع داده

- بازار ایران: Baha24 بدون کلید، سپس BrsApi با کلید رایگان مستندات، یا `NAVASAN_API_KEY` اگر کلید رسمی نوسان دارید.
- رمزارزها: Binance Public API، با fallback به CoinGecko.
- ارزهای فیات و افغانی: ExchangeRate-API Open Endpoint.
- طلای جهانی: اگر `GOLDAPI_KEY` تنظیم شود GoldAPI، در غیر این صورت PAXG/Binance به عنوان proxy بازار طلا.

برنامه عدد ساختگی نمایش نمی‌دهد. اگر یک منبع قطع شود، همان بخش پیام خطا می‌دهد.

## اجرای محلی

```bash
npm install
npm run build
node server.mjs
```

سپس `http://localhost:4173` را باز کنید.

## استقرار روی Railway

1. پروژه را در GitHub بگذارید.
2. در Railway گزینه Deploy from GitHub Repo را بزنید.
3. Railway با `npm run build` خروجی را می‌سازد.
4. Start command از قبل تنظیم شده است: `node server.mjs`.
5. در صورت نیاز Environment Variables را اضافه کنید:
   - `BRS_API_KEY`: کلید BrsApi برای بازار ایران. Baha24 بدون کلید استفاده می‌شود؛ اگر Baha24 قطع شد، BrsApi fallback است. یک کلید رایگان پیش‌فرض از مستندات داخل سرور گذاشته شده، اما برای پایداری بهتر کلید خودتان را بگذارید.
   - `NAVASAN_API_KEY`: اگر API رسمی Navasan دارید، اولویت با آن است.
   - `GOLDAPI_KEY`: برای قیمت دقیق‌تر XAU/USD از GoldAPI.

پس از Deploy، از Settings > Networking دامنه عمومی Railway را فعال کنید.