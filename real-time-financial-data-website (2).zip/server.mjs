import { createReadStream, existsSync, statSync } from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.join(__dirname, "dist");
const port = Number(process.env.PORT || 4173);
const CACHE_MS = 15_000;
const BRS_API_KEY = process.env.BRS_API_KEY || "FreeSV0E1LSgB9RDjuf0QorSLViX8pPG";
const NAVASAN_API_KEY = process.env.NAVASAN_API_KEY || "";
const GOLDAPI_KEY = process.env.GOLDAPI_KEY || process.env.GOLD_API_KEY || "";

let marketCache = { at: 0, data: null };

const fiatMeta = {
  USD: ["دلار آمریکا", "USD"],
  EUR: ["یورو", "EUR"],
  GBP: ["پوند انگلیس", "GBP"],
  AFN: ["افغانی افغانستان", "AFN"],
  AED: ["درهم امارات", "AED"],
  TRY: ["لیر ترکیه", "TRY"],
  IRR: ["ریال ایران", "IRR"],
  SAR: ["ریال عربستان", "SAR"],
  QAR: ["ریال قطر", "QAR"],
  KWD: ["دینار کویت", "KWD"],
  IQD: ["دینار عراق", "IQD"],
  CNY: ["یوان چین", "CNY"],
  JPY: ["ین ژاپن", "JPY"],
  RUB: ["روبل روسیه", "RUB"],
  INR: ["روپیه هند", "INR"],
  PKR: ["روپیه پاکستان", "PKR"],
  CAD: ["دلار کانادا", "CAD"],
  AUD: ["دلار استرالیا", "AUD"],
  CHF: ["فرانک سوئیس", "CHF"],
  AZN: ["منات آذربایجان", "AZN"],
  GEL: ["لاری گرجستان", "GEL"],
  AMD: ["درام ارمنستان", "AMD"],
  OMR: ["ریال عمان", "OMR"],
  BHD: ["دینار بحرین", "BHD"],
  SEK: ["کرون سوئد", "SEK"],
  NOK: ["کرون نروژ", "NOK"],
  DKK: ["کرون دانمارک", "DKK"],
  MYR: ["رینگیت مالزی", "MYR"],
  THB: ["بات تایلند", "THB"],
  KRW: ["وون کره جنوبی", "KRW"],
  SGD: ["دلار سنگاپور", "SGD"],
  HKD: ["دلار هنگ‌کنگ", "HKD"],
  EGP: ["پوند مصر", "EGP"],
  ZAR: ["راند آفریقای جنوبی", "ZAR"],
  BRL: ["رئال برزیل", "BRL"],
  MXN: ["پزو مکزیک", "MXN"],
};

const fiatOrder = Object.keys(fiatMeta);

const cryptoMeta = [
  ["BTCUSDT", "BTC", "بیت‌کوین", "Bitcoin"],
  ["ETHUSDT", "ETH", "اتریوم", "Ethereum"],
  ["BNBUSDT", "BNB", "بایننس کوین", "BNB"],
  ["SOLUSDT", "SOL", "سولانا", "Solana"],
  ["XRPUSDT", "XRP", "ریپل", "XRP"],
  ["ADAUSDT", "ADA", "کاردانو", "Cardano"],
  ["DOGEUSDT", "DOGE", "دوج کوین", "Dogecoin"],
  ["TRXUSDT", "TRX", "ترون", "TRON"],
  ["DOTUSDT", "DOT", "پولکادات", "Polkadot"],
  ["POLUSDT", "POL", "پالیگان", "Polygon"],
  ["LTCUSDT", "LTC", "لایت کوین", "Litecoin"],
  ["1000SHIBUSDT", "SHIB", "شیبا اینو", "Shiba Inu"],
  ["AVAXUSDT", "AVAX", "آوالانچ", "Avalanche"],
  ["LINKUSDT", "LINK", "چین لینک", "Chainlink"],
  ["USDCUSDT", "USDC", "یو اس دی کوین", "USD Coin"],
  ["PAXGUSDT", "PAXG", "پکس گلد", "PAX Gold"],
];

const coinGeckoIds = {
  bitcoin: ["BTC", "بیت‌کوین", "Bitcoin"],
  ethereum: ["ETH", "اتریوم", "Ethereum"],
  binancecoin: ["BNB", "بایننس کوین", "BNB"],
  solana: ["SOL", "سولانا", "Solana"],
  ripple: ["XRP", "ریپل", "XRP"],
  cardano: ["ADA", "کاردانو", "Cardano"],
  dogecoin: ["DOGE", "دوج کوین", "Dogecoin"],
  tron: ["TRX", "ترون", "TRON"],
  polkadot: ["DOT", "پولکادات", "Polkadot"],
  litecoin: ["LTC", "لایت کوین", "Litecoin"],
  "shiba-inu": ["SHIB", "شیبا اینو", "Shiba Inu"],
  "avalanche-2": ["AVAX", "آوالانچ", "Avalanche"],
  chainlink: ["LINK", "چین لینک", "Chainlink"],
  "usd-coin": ["USDC", "یو اس دی کوین", "USD Coin"],
  "pax-gold": ["PAXG", "پکس گلد", "PAX Gold"],
};

function parseNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const normalized = String(value)
    .replace(/[۰-۹]/g, (digit) => "۰۱۲۳۴۵۶۷۸۹".indexOf(digit))
    .replace(/[٠-٩]/g, (digit) => "٠١٢٣٤٥٦٧٨٩".indexOf(digit))
    .replace(/,/g, "")
    .replace(/\s/g, "")
    .replace(/[^0-9.+-]/g, "");
  const number = Number(normalized);
  return Number.isFinite(number) ? number : null;
}

function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[۰-۹]/g, (digit) => "۰۱۲۳۴۵۶۷۸۹".indexOf(digit))
    .replace(/[٠-٩]/g, (digit) => "٠١٢٣٤٥٦٧٨٩".indexOf(digit));
}

function validTime(value) {
  if (typeof value === "string" && /\d{4}-\d{2}-\d{2}/.test(value)) {
    const parsed = Date.parse(value.replace(" ", "T"));
    if (Number.isFinite(parsed)) return parsed;
  }
  const raw = parseNumber(value);
  if (!raw) return null;
  const ms = raw > 1e12 ? raw : raw * 1000;
  const lowerBound = Date.UTC(2020, 0, 1);
  const upperBound = Date.now() + 45 * 24 * 60 * 60 * 1000;
  return ms >= lowerBound && ms <= upperBound ? ms : null;
}

async function getJson(url, options = {}, timeoutMs = 9_000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        accept: "application/json,text/plain,*/*",
        "user-agent": "RailwayLiveMarket/1.0",
        ...(options.headers || {}),
      },
    });
    const body = await response.text();
    if (!response.ok) throw new Error(`${response.status} ${body.slice(0, 120)}`);
    return JSON.parse(body.replace(/^\uFEFF/, ""));
  } finally {
    clearTimeout(timeout);
  }
}

function flattenRecords(input) {
  const records = [];
  const walk = (value, group = "") => {
    if (Array.isArray(value)) {
      value.forEach((entry) => walk(entry, group));
      return;
    }
    if (!value || typeof value !== "object") return;

    const price = parseNumber(
      value.price ?? value.value ?? value.sell ?? value.buy ?? value.last ?? value.last_price ?? value.close,
    );
    const hasIdentity = value.symbol || value.name || value.name_en || value.title || value.code || value.slug;
    if (price !== null && hasIdentity) {
      records.push({
        symbol: String(value.symbol || value.code || value.slug || "").toUpperCase(),
        name: String(value.name || value.title || ""),
        nameEn: String(value.name_en || value.nameEn || ""),
        value: price,
        changePercent: parseNumber(value.change_percent ?? value.change_pct ?? value.percent_change),
        changeValue: parseNumber(value.change_value ?? value.change_val ?? value.change),
        updatedAt: validTime(
          value.time_unix ?? value.timestamp ?? value.date_unix ?? value.last_update ?? value.date,
        ),
        group,
      });
    }

    Object.entries(value).forEach(([key, entry]) => walk(entry, key));
  };
  walk(input);
  return records;
}

function recordText(record) {
  return normalizeText(`${record.symbol} ${record.name} ${record.nameEn} ${record.group}`);
}

function findRecord(records, symbols, includes, excludes = []) {
  const normalizedSymbols = symbols.map((symbol) => symbol.toUpperCase());
  const exact = records.find((record) => normalizedSymbols.includes(record.symbol));
  if (exact) return exact;

  return records.find((record) => {
    const text = recordText(record);
    const symbolHit = normalizedSymbols.some((symbol) => record.symbol.includes(symbol));
    const includeHit = includes.every((word) => text.includes(normalizeText(word)));
    const excludeHit = excludes.some((word) => text.includes(normalizeText(word)));
    return (symbolHit || includeHit) && !excludeHit;
  });
}

function itemFromRecord(record, key, title, subtitle, unit, source) {
  if (!record || !Number.isFinite(record.value) || record.value <= 0) return null;
  return {
    key,
    title,
    subtitle,
    symbol: record.symbol || key.toUpperCase(),
    value: record.value,
    unit,
    changePercent: record.changePercent ?? undefined,
    changeValue: record.changeValue ?? undefined,
    source,
    updatedAt: record.updatedAt,
  };
}

function compact(items) {
  return items.filter(Boolean);
}

async function fetchBaha24Market() {
  const json = await getJson("https://baha24.com/api/v1/price");
  const records = flattenRecords(json).filter((record) => record.value > 0);
  if (!records.length) throw new Error("Baha24 returned no price records");

  const source = "Baha24 live";
  const bySymbol = (symbol) => records.find((record) => record.symbol === symbol);
  const item = (symbol, key, title, subtitle, unit = "تومان") =>
    itemFromRecord(bySymbol(symbol), key, title, subtitle, unit, source);

  const usd = bySymbol("USD");
  const usdt = bySymbol("USDT");
  const usdToman = usd?.value || usdt?.value || null;

  const currency = compact([
    item("USD", "usd", "دلار بازار آزاد", "USD"),
    item("EUR", "eur", "یورو بازار آزاد", "EUR"),
    item("AFN", "afn", "افغانی افغانستان", "AFN"),
    item("GBP", "gbp", "پوند انگلیس", "GBP"),
    item("AED", "aed", "درهم امارات", "AED"),
    item("TRY", "try", "لیر ترکیه", "TRY"),
    item("CNY", "cny", "یوان چین", "CNY"),
    item("INR", "inr", "روپیه هند", "INR"),
  ]);

  const gold = compact([
    item("GOL18", "gold18", "طلای ۱۸ عیار", "هر گرم"),
    item("MITHQAL", "mesghal", "مثقال طلا", "طلای آبشده"),
    item("OUNCE", "xau-usd-iran", "انس طلای جهانی", "XAU/USD", "دلار"),
  ]);

  const coins = compact([
    item("EMAMI1", "sekkeh", "سکه امامی", "طرح جدید"),
    item("AZADI1", "bahar", "تمام سکه", "بهار آزادی"),
    item("AZADI1_2", "nim", "نیم سکه", "بهار آزادی"),
    item("AZADI1_4", "rob", "ربع سکه", "بهار آزادی"),
    item("AZADI1G", "gerami", "سکه گرمی", "یک گرمی"),
  ]);

  const cryptoBase = compact([item("USDT", "usdt-iran", "تتر", "USDT بازار ایران")]);
  const crypto = [...cryptoBase];
  const cryptoToman = (symbol, key, title) => {
    const record = bySymbol(symbol);
    if (!record || !usdToman) return null;
    return {
      key,
      title,
      subtitle: `${symbol} • محاسبه با ${record.value.toLocaleString("fa-IR")} دلار و تتر بازار ایران`,
      symbol,
      value: record.value * usdToman,
      unit: "تومان",
      source,
      updatedAt: record.updatedAt,
    };
  };
  crypto.push(
    ...compact([
      cryptoToman("BITCOIN", "btc-iran", "بیت‌کوین"),
      cryptoToman("ETH", "eth-iran", "اتریوم"),
      cryptoToman("BNB", "bnb-iran", "بایننس کوین"),
      cryptoToman("SOL", "sol-iran", "سولانا"),
      cryptoToman("XRP", "xrp-iran", "ریپل"),
      cryptoToman("TRX", "trx-iran", "ترون"),
      cryptoToman("LTC", "ltc-iran", "لایت کوین"),
      cryptoToman("DOGE", "doge-iran", "دوج کوین"),
      cryptoToman("DOT", "dot-iran", "پولکادات"),
      cryptoToman("TON", "ton-iran", "تون کوین"),
      cryptoToman("ADA", "ada-iran", "کاردانو"),
      cryptoToman("AVAX", "avax-iran", "آوالانچ"),
      cryptoToman("LINK", "link-iran", "چین لینک"),
      cryptoToman("SHIB", "shib-iran", "شیبا اینو"),
      cryptoToman("UNI", "uni-iran", "یونی سواپ"),
      cryptoToman("BCH", "bch-iran", "بیت کوین کش"),
      cryptoToman("XMR", "xmr-iran", "مونرو"),
    ]),
  );

  const all = [...currency, ...gold, ...coins, ...crypto];
  const updatedAt = all.reduce((max, current) => Math.max(max, current.updatedAt || 0), 0);

  return {
    ok: true,
    source,
    usdToman,
    status: { name: source, ok: true, updatedAt: updatedAt || null },
    data: { currency, gold, coins, crypto },
  };
}

async function fetchNavasanOfficial() {
  if (!NAVASAN_API_KEY) throw new Error("NAVASAN_API_KEY is not set");
  const json = await getJson(`https://api.navasan.tech/latest/?api_key=${encodeURIComponent(NAVASAN_API_KEY)}`);
  const get = (key) => json[key] || {};
  const record = (key) => ({
    symbol: key.toUpperCase(),
    name: key,
    nameEn: key,
    value: parseNumber(get(key).value),
    changePercent: parseNumber(get(key).change_pct),
    changeValue: parseNumber(get(key).change_val),
    updatedAt: validTime(get(key).timestamp ?? get(key).date),
  });
  const source = "Navasan official";
  const currency = compact([
    itemFromRecord(record("usd"), "usd", "دلار بازار آزاد", "USD", "تومان", source),
    itemFromRecord(record("eur"), "eur", "یورو بازار آزاد", "EUR", "تومان", source),
    itemFromRecord(record("afn"), "afn", "افغانی افغانستان", "AFN", "تومان", source),
    itemFromRecord(record("aed"), "aed", "درهم امارات", "AED", "تومان", source),
    itemFromRecord(record("try"), "try", "لیر ترکیه", "TRY", "تومان", source),
  ]);
  const gold = compact([
    itemFromRecord(record("18ayar"), "gold18", "طلای ۱۸ عیار", "هر گرم", "تومان", source),
    itemFromRecord(record("xau"), "gold24", "طلای ۲۴ عیار", "هر گرم", "تومان", source),
    itemFromRecord(record("abshodeh"), "abshodeh", "طلای آبشده", "مثقال", "تومان", source),
  ]);
  const coins = compact([
    itemFromRecord(record("sekkeh"), "sekkeh", "سکه امامی", "طرح جدید", "تومان", source),
    itemFromRecord(record("bahar"), "bahar", "سکه بهار آزادی", "طرح قدیم", "تومان", source),
    itemFromRecord(record("nim"), "nim", "نیم سکه", "بهار آزادی", "تومان", source),
    itemFromRecord(record("rob"), "rob", "ربع سکه", "بهار آزادی", "تومان", source),
    itemFromRecord(record("gerami"), "gerami", "سکه گرمی", "یک گرمی", "تومان", source),
  ]);
  const crypto = compact([
    itemFromRecord(record("btc"), "btc-iran", "بیت‌کوین", "BTC بازار ایران", "تومان", source),
  ]);
  const updatedAt = [...currency, ...gold, ...coins, ...crypto].reduce(
    (max, item) => Math.max(max, item.updatedAt || 0),
    0,
  );

  return {
    ok: true,
    source,
    usdToman: currency.find((item) => item.key === "usd")?.value || null,
    status: { name: source, ok: true, updatedAt: updatedAt || null },
    data: { currency, gold, coins, crypto },
  };
}

async function fetchBrsMarket() {
  const urls = [
    `https://Api.BrsApi.ir/Market/Gold_Currency_Pro.php?key=${encodeURIComponent(BRS_API_KEY)}&section=gold,currency,cryptocurrency`,
    `https://Api.BrsApi.ir/Market/Gold_Currency.php?key=${encodeURIComponent(BRS_API_KEY)}`,
  ];
  let json = null;
  let lastError = "";
  for (const url of urls) {
    try {
      json = await getJson(url);
      break;
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
    }
  }
  if (!json) throw new Error(lastError || "BrsApi failed");

  const records = flattenRecords(json).filter((record) => record.value > 0);
  if (!records.length) throw new Error("BrsApi returned no price records");

  const source = "BrsApi live";
  const usd = findRecord(records, ["IR_USD", "USD"], ["دلار"], ["تتر", "کانادا", "استرالیا", "سکه"]);
  const eur = findRecord(records, ["IR_EUR", "EUR"], ["یورو"], []);
  const afn = findRecord(records, ["IR_AFN", "AFN"], ["افغانی"], []);
  const aed = findRecord(records, ["IR_AED", "AED"], ["درهم"], []);
  const tryRec = findRecord(records, ["IR_TRY", "TRY"], ["لیر"], []);
  const usdt = findRecord(records, ["USDT"], ["تتر"], ["usdc"]);
  const btc = findRecord(records, ["BTC"], ["بیت"], []);

  const gold18 = findRecord(records, ["IR_GOLD_18K", "18K", "18AYAR"], ["18"], []);
  const gold24 = findRecord(records, ["IR_GOLD_24K", "24K", "XAU"], ["24"], ["اونس"]);
  const mesghal = findRecord(records, ["MESGHAL", "ABSHODEH"], ["مثقال"], []);
  const xauUsd = findRecord(records, ["XAUUSD", "ONS", "XAU"], ["اونس"], ["مثقال"]);

  const emami = findRecord(records, ["IR_COIN_EMAMI", "EMAMI"], ["امامی"], []);
  const bahar = findRecord(records, ["IR_COIN_BAHAR", "BAHAR"], ["بهار"], ["نیم", "ربع"]);
  const nim = findRecord(records, ["IR_COIN_HALF", "NIM", "HALF"], ["نیم"], []);
  const rob = findRecord(records, ["IR_COIN_QUARTER", "ROB", "QUARTER"], ["ربع"], []);
  const gerami = findRecord(records, ["IR_COIN_1G", "GERAMI"], ["گرمی"], ["طلا"]);

  const currency = compact([
    itemFromRecord(usd, "usd", "دلار بازار آزاد", "USD", "تومان", source),
    itemFromRecord(eur, "eur", "یورو بازار آزاد", "EUR", "تومان", source),
    itemFromRecord(afn, "afn", "افغانی افغانستان", "AFN", "تومان", source),
    itemFromRecord(aed, "aed", "درهم امارات", "AED", "تومان", source),
    itemFromRecord(tryRec, "try", "لیر ترکیه", "TRY", "تومان", source),
  ]);
  const gold = compact([
    itemFromRecord(gold18, "gold18", "طلای ۱۸ عیار", "هر گرم", "تومان", source),
    itemFromRecord(gold24, "gold24", "طلای ۲۴ عیار", "هر گرم", "تومان", source),
    itemFromRecord(mesghal, "mesghal", "مثقال طلا", "طلای آبشده", "تومان", source),
    itemFromRecord(xauUsd, "xau-usd-iran", "انس طلای جهانی", "بازار ایران", "دلار", source),
  ]);
  const coins = compact([
    itemFromRecord(emami, "sekkeh", "سکه امامی", "طرح جدید", "تومان", source),
    itemFromRecord(bahar, "bahar", "سکه بهار آزادی", "طرح قدیم", "تومان", source),
    itemFromRecord(nim, "nim", "نیم سکه", "بهار آزادی", "تومان", source),
    itemFromRecord(rob, "rob", "ربع سکه", "بهار آزادی", "تومان", source),
    itemFromRecord(gerami, "gerami", "سکه گرمی", "یک گرمی", "تومان", source),
  ]);
  const crypto = compact([
    itemFromRecord(usdt, "usdt-iran", "تتر", "USDT بازار ایران", "تومان", source),
    itemFromRecord(btc, "btc-iran", "بیت‌کوین", "BTC بازار ایران", "تومان", source),
  ]);
  const all = [...currency, ...gold, ...coins, ...crypto];
  const updatedAt = all.reduce((max, item) => Math.max(max, item.updatedAt || 0), 0);

  return {
    ok: true,
    source,
    usdToman: currency.find((item) => item.key === "usd")?.value || usdt?.value || null,
    status: { name: source, ok: true, updatedAt: updatedAt || null },
    data: { currency, gold, coins, crypto },
  };
}

async function fetchIranMarket() {
  if (NAVASAN_API_KEY) {
    try {
      return await fetchNavasanOfficial();
    } catch (error) {
      console.error("Navasan failed:", error instanceof Error ? error.message : error);
    }
  }

  try {
    return await fetchBaha24Market();
  } catch (error) {
    console.error("Baha24 failed:", error instanceof Error ? error.message : error);
  }

  try {
    return await fetchBrsMarket();
  } catch (error) {
    return {
      ok: false,
      source: "Baha24 / BrsApi / Navasan",
      usdToman: null,
      status: {
        name: "Baha24 / BrsApi / Navasan",
        ok: false,
        message: error instanceof Error ? error.message : "Iran market API failed",
      },
      data: { currency: [], gold: [], coins: [], crypto: [] },
    };
  }
}

async function fetchFiat(usdToman) {
  try {
    const json = await getJson("https://open.er-api.com/v6/latest/USD");
    const rates = json.rates || json.conversion_rates || {};
    const afnRate = rates.AFN;
    const items = fiatOrder
      .filter((code) => Number.isFinite(rates[code]))
      .map((code) => {
        const [title, symbol] = fiatMeta[code];
        const perUsd = rates[code];
        const inAfn = Number.isFinite(afnRate) ? afnRate / perUsd : null;
        const value = usdToman ? usdToman / perUsd : inAfn;
        return {
          key: `fiat-${code}`,
          title,
          subtitle: inAfn ? `${symbol} • هر واحد ${inAfn.toLocaleString("fa-IR", { maximumFractionDigits: 4 })} افغانی` : symbol,
          symbol,
          value: value || 0,
          unit: usdToman ? "تومان" : "افغانی",
          source: "ExchangeRate-API",
          updatedAt: validTime(json.time_last_update_unix),
        };
      });

    return {
      ok: true,
      items,
      status: {
        name: "ExchangeRate-API",
        ok: true,
        updatedAt: validTime(json.time_last_update_unix),
        message: "نرخ مرجع ارزها، معمولا روزانه به‌روزرسانی می‌شود",
      },
    };
  } catch (error) {
    return {
      ok: false,
      items: [],
      status: {
        name: "ExchangeRate-API",
        ok: false,
        message: error instanceof Error ? error.message : "Fiat API failed",
      },
    };
  }
}

async function fetchCryptoFromBinance(usdToman) {
  const symbols = cryptoMeta.map(([pair]) => pair);
  const url = `https://api.binance.com/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(symbols))}`;
  const json = await getJson(url);
  const rows = Array.isArray(json) ? json : [];
  const byPair = new Map(rows.map((row) => [row.symbol, row]));
  const items = cryptoMeta
    .map(([pair, symbol, faName, enName]) => {
      const row = byPair.get(pair);
      const price = parseNumber(row?.lastPrice);
      if (!price) return null;
      const tomanText = usdToman ? ` • ${Math.round(price * usdToman).toLocaleString("fa-IR")} تومان` : "";
      return {
        key: `crypto-${symbol}`,
        title: faName,
        subtitle: `${enName}${tomanText}`,
        symbol,
        value: price,
        unit: "دلار",
        changePercent: parseNumber(row?.priceChangePercent) ?? undefined,
        source: "Binance",
        updatedAt: validTime(row?.closeTime),
      };
    })
    .filter(Boolean);
  return { source: "Binance", items };
}

async function fetchCryptoFromCoinGecko(usdToman) {
  const ids = Object.keys(coinGeckoIds).join(",");
  const json = await getJson(
    `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`,
  );
  const items = Object.entries(coinGeckoIds)
    .map(([id, [symbol, faName, enName]]) => {
      const price = parseNumber(json[id]?.usd);
      if (!price) return null;
      const tomanText = usdToman ? ` • ${Math.round(price * usdToman).toLocaleString("fa-IR")} تومان` : "";
      return {
        key: `crypto-${symbol}`,
        title: faName,
        subtitle: `${enName}${tomanText}`,
        symbol,
        value: price,
        unit: "دلار",
        changePercent: parseNumber(json[id]?.usd_24h_change) ?? undefined,
        source: "CoinGecko",
        updatedAt: Date.now(),
      };
    })
    .filter(Boolean);
  return { source: "CoinGecko", items };
}

async function fetchCrypto(usdToman) {
  try {
    const market = await fetchCryptoFromBinance(usdToman);
    return {
      ok: true,
      items: market.items,
      status: { name: market.source, ok: true, updatedAt: Date.now() },
    };
  } catch (binanceError) {
    try {
      const market = await fetchCryptoFromCoinGecko(usdToman);
      return {
        ok: true,
        items: market.items,
        status: {
          name: market.source,
          ok: true,
          updatedAt: Date.now(),
          message: "Binance در دسترس نبود؛ CoinGecko استفاده شد",
        },
      };
    } catch {
      return {
        ok: false,
        items: [],
        status: {
          name: "Binance / CoinGecko",
          ok: false,
          message: binanceError instanceof Error ? binanceError.message : "Crypto API failed",
        },
      };
    }
  }
}

async function fetchGoldApi() {
  if (!GOLDAPI_KEY) throw new Error("GOLDAPI_KEY is not set");
  const json = await getJson("https://www.goldapi.io/api/XAU/USD", {
    headers: { "x-access-token": GOLDAPI_KEY },
  });
  const ounce = parseNumber(json.price);
  if (!ounce) throw new Error("GoldAPI returned no price");
  return {
    source: "GoldAPI",
    ounce,
    gram24: parseNumber(json.price_gram_24k),
    gram22: parseNumber(json.price_gram_22k),
    gram21: parseNumber(json.price_gram_21k),
    gram18: parseNumber(json.price_gram_18k),
    changePercent: parseNumber(json.chp),
    updatedAt: validTime(json.timestamp),
  };
}

function buildGoldItems(gold, usdToman) {
  const items = [
    {
      key: "global-xau-ounce",
      title: "انس طلای جهانی",
      subtitle: "XAU/USD",
      symbol: "XAU",
      value: gold.ounce,
      unit: "دلار",
      changePercent: gold.changePercent ?? undefined,
      source: gold.source,
      updatedAt: gold.updatedAt,
    },
  ];

  const grams = [
    ["global-gold24", "طلای ۲۴ عیار جهانی", "هر گرم", "24K", gold.gram24],
    ["global-gold22", "طلای ۲۲ عیار جهانی", "هر گرم", "22K", gold.gram22],
    ["global-gold21", "طلای ۲۱ عیار جهانی", "هر گرم", "21K", gold.gram21],
    ["global-gold18", "طلای ۱۸ عیار جهانی", "هر گرم", "18K", gold.gram18],
  ];

  grams.forEach(([key, title, subtitle, symbol, value]) => {
    const numericValue = parseNumber(value);
    if (!numericValue) return;
    items.push({
      key,
      title,
      subtitle: usdToman ? `${subtitle} • ${Math.round(numericValue * usdToman).toLocaleString("fa-IR")} تومان` : subtitle,
      symbol,
      value: numericValue,
      unit: "دلار",
      changePercent: gold.changePercent ?? undefined,
      source: gold.source,
      updatedAt: gold.updatedAt,
    });
  });

  return items;
}

function goldFromPaxg(cryptoItems) {
  const paxg = cryptoItems.find((item) => item.symbol === "PAXG");
  if (!paxg) return null;
  const gram24 = paxg.value / 31.1034768;
  return {
    source: "PAXG/Binance",
    ounce: paxg.value,
    gram24,
    gram22: gram24 * 0.916,
    gram21: gram24 * 0.875,
    gram18: gram24 * 0.75,
    changePercent: paxg.changePercent,
    updatedAt: paxg.updatedAt,
  };
}

async function buildMarketData() {
  const iran = await fetchIranMarket();
  const usdToman = iran.usdToman;
  const [fiat, crypto] = await Promise.all([fetchFiat(usdToman), fetchCrypto(usdToman)]);

  let gold = null;
  let goldStatus = { name: "GoldAPI / PAXG", ok: false, message: "Gold source unavailable" };
  try {
    gold = await fetchGoldApi();
    goldStatus = { name: gold.source, ok: true, updatedAt: gold.updatedAt || Date.now() };
  } catch {
    gold = goldFromPaxg(crypto.items);
    if (gold) goldStatus = { name: gold.source, ok: true, updatedAt: gold.updatedAt || Date.now() };
  }

  const globalGold = gold ? buildGoldItems(gold, usdToman) : [];

  return {
    fetchedAt: Date.now(),
    usdToman,
    sources: {
      iran: iran.status,
      fiat: fiat.status,
      crypto: crypto.status,
      gold: goldStatus,
    },
    iran: iran.data,
    fiat: fiat.items,
    crypto: crypto.items.filter((item) => item.symbol !== "PAXG"),
    globalGold,
  };
}

async function handleApi(response) {
  const now = Date.now();
  if (!marketCache.data || now - marketCache.at > CACHE_MS) {
    marketCache = { at: now, data: await buildMarketData() };
  }
  sendJson(response, 200, marketCache.data);
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
  });
  response.end(JSON.stringify(payload));
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".ico": "image/x-icon",
  }[ext] || "application/octet-stream";
}

async function serveStatic(request, response) {
  const url = new URL(request.url || "/", `http://${request.headers.host}`);
  const safePath = path.normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[/\\])+/, "");
  let filePath = path.join(distDir, safePath === "/" ? "index.html" : safePath);

  if (!filePath.startsWith(distDir)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  if (!existsSync(filePath) || statSync(filePath).isDirectory()) {
    filePath = path.join(distDir, "index.html");
  }

  try {
    response.writeHead(200, {
      "content-type": contentType(filePath),
      "cache-control": filePath.endsWith("index.html") ? "no-store" : "public, max-age=31536000, immutable",
    });
    createReadStream(filePath).pipe(response);
  } catch {
    response.writeHead(404);
    response.end("Not found");
  }
}

const server = http.createServer(async (request, response) => {
  try {
    if (request.url?.startsWith("/api/market")) {
      await handleApi(response);
      return;
    }
    if (request.url === "/health") {
      sendJson(response, 200, { ok: true });
      return;
    }
    await serveStatic(request, response);
  } catch (error) {
    sendJson(response, 500, {
      ok: false,
      message: error instanceof Error ? error.message : "Server error",
    });
  }
});

if (!existsSync(path.join(distDir, "index.html"))) {
  console.warn("dist/index.html not found. Run npm run build before starting the server.");
}

server.listen(port, "0.0.0.0", () => {
  console.log(`Live market server running on port ${port}`);
});